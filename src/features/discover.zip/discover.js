import axios from 'axios';

// 글 탭에 필요한 정보
axios({
  method: 'get',
  url: '/api/posts',
  headers: {
    'client-id': 'vanilla03',
    'content-type': 'application/json',
    accept: 'application/json',
  },
  params: {
    title: title,
    author: author,
    user.name: name,
    content: content,
    createdAt: createdAt,
    img: ${}
  },
})
  .then(response => {
    
  })
  .catch(error => {
    
  });

document.addEventListener('DOMContentLoaded', function () {
  const $input = document.querySelector('.discover__header-input'); // 검색 입력창
  const $posts = document.querySelector('.post'); // 글 영역
  const $authors = document.querySelector('.author__lists'); // 작가 영역
  const $tabPosts = document.querySelector('.discover__nav-tab:first-child'); // 글 탭
  const $tabAuthors = document.querySelector('.discover__nav-tab:last-child'); // 작가 탭
  const $resetBtn = document.querySelector('.discover__header-close'); // x 버튼

  // 글 탭 클릭 시 글 리스트 보여주기
  $tabPosts.addEventListener('click', function () {
    showTab('posts');
  });

  // 작가 탭 클릭 시 작가 리스트 보여주기
  $tabAuthors.addEventListener('click', function () {
    showTab('authors');
  });

  // 탭 전환 함수
  function showTab(tab) {
    if (tab === 'posts') {
      $posts.style.display = 'block';
      $authors.style.display = 'none';

      // 글 탭 활성화
      $tabPosts.classList.add('active');
      $tabAuthors.classList.remove('active');
    } else {
      $posts.style.display = 'none';
      $authors.style.display = 'block';

      // 작가 탭 활성화
      $tabPosts.classList.remove('active');
      $tabAuthors.classList.add('active');
    }
  }

  // 검색 입력 시 실행
  $input.addEventListener('input', function () {
    const keyword = $input.value.trim();

    if (keyword.length > 0) {
      search(keyword);
    } else {
      clearResults();
    }
  });

  // 검색 함수 (axios로 데이터를 가져옴)
  function search(keyword) {
    axios
      .get('/api/posts?type=info', {
        headers: {
          'client-id': 'vanilla03', // client-id 헤더 추가
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
      })
      .then(function (response) {
        const data = response.data;

        const filtered = data.filter(function (item) {
          return item.title.includes(keyword) || item.content.includes(keyword);
        });

        if (filtered.length > 0) {
          updateUI(filtered);
        } else {
          showNoResults(); // 검색 결과가 없을 때 '검색 결과 없음' 화면 출력
        }
      })
      .catch(function (error) {
        console.error('Error:', error); // 에러는 콘솔에만 출력, 사용자에게 에러 메시지는 표시하지 않음
        showNoResults(); // 데이터가 없거나 에러가 발생해도 '검색 결과 없음' 화면 출력
      });
  }

  // 결과 업데이트 함수
  function updateUI(data) {
    const html = data
      .map(function (post) {
        return `
        <div class="post__lists">
            <div>
                <h3 class="post__list-title">${post.title}</h3>
            </div>
            <div class="post__list-content">
                <div class="content__text">
                    <p class="content__text-main">${post.content.slice(0, 100)}...</p>
                    <div class="content__text-info">
                        ${post.createdAt} <div class="circle"></div> by ${post.user.name}
                    </div>
                </div>
                <div class="content__cover">
                    <img src="${post.user.image}" alt="관련 이미지" loading="lazy">
                </div>
            </div>
        </div>
      `;
      })
      .join('');

    $posts.innerHTML = html;
  }

  // 검색 결과가 없을 때 처리
  function showNoResults() {
    $posts.innerHTML = `
      <div class="discover__none">
        <div class="discover__result-noneImg">
          <img src="../../../assets/images/home/no_profile.svg" alt="검색 결과 없음"> <!-- 이미지 경로 수정 -->
        </div>
        <p class="discover__result-none">검색 결과가 없습니다.</p>
      </div>
    `;
  }

  // X 버튼 클릭 시 실행되는 함수
  $resetBtn.addEventListener('click', function () {
    console.log('x 버튼 클릭됨');
    // 1. 검색 입력창 초기화
    $input.value = '';

    // 2. 검색 결과와 글/작가 영역 초기화
    clearResults();

    // 3. 초기 화면으로 돌아가기 (탭 상태 초기화)
    initPage();
  });

  // 검색 결과를 초기화하는 함수
  function clearResults() {
    $posts.innerHTML = ''; // 글 검색 결과 영역 비움
    $authors.innerHTML = ''; // 작가 검색 결과 영역 비움
  }

  // 페이지 초기화 함수
  function initPage() {
    $posts.style.display = 'none'; // 글 영역 숨김
    $authors.style.display = 'none'; // 작가 영역 숨김
    $tabPosts.classList.add('active'); // 글 탭을 기본으로 활성화
    $tabAuthors.classList.remove('active'); // 작가 탭 비활성화
  }

  initPage(); // 페이지가 처음 로드될 때 초기화 호출
});
